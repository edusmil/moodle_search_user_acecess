# moodle_search_user_acecess
Search for last user access<br>
This is moodle plugin that searches for last user access in the plataform.
